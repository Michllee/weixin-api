
    $('.minus,.plus').hover(function(){
        if($(this).hasClass('minus') && $('.card-nums').val() && parseInt($('.card-nums').val())>0){
            $(this).addClass('active');
        }
        if($(this).hasClass('plus')){
            $(this).addClass('active');
        }
    },function(){
        $(this).removeClass('active');
    });

    $('.minus,.plus').on('click',function(){
        if($(this).hasClass('minus')&& $('.card-nums').val() && parseInt($('.card-nums').val()) > 0){
            $('.card-nums').val(parseInt($('.card-nums').val())-1);
            
        }
        if($(this).hasClass('plus')){
            $('.card-nums').val(parseInt($('.card-nums').val())+1)
        }
    })
